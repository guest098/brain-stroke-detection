from django.contrib import admin
from django.urls import path
from app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.home, name='home'),
    path('nvb/', views.nvb, name='nvb'),
    path('pac/', views.pac, name='pac'),
    path('svm/', views.svm, name='svm'),
    path('dec/', views.dec, name='dec'),
    path('randomf/', views.randomf, name='randomf'),
    path('mnb/', views.mnb, name='mnb'),
    path('graph/', views.graph, name='graph'),
    path('', views.accuracy, name='accuracy'),
    path('loginCheck/', views.loginCheck, name='loginCheck'),
    path('reg/', views.reg, name='reg'),
    path('login/', views.login, name='login'),
    path('save/', views.save, name='save'),
    path('logout/', views.logout, name='logout'),
]
